﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Speech.Synthesis;
using System.Diagnostics;
using WMPLib;
using System.Threading;
using System.IO;

namespace GuessingGameProject
{
    public partial class GuessingGameForm : Form
    {
        WindowsMediaPlayer music = new WindowsMediaPlayer();
        public static GuessingGameForm objGuessing = new GuessingGameForm();
        SpeechSynthesizer speaker = new SpeechSynthesizer();


        public GuessingGameForm()
        {
            InitializeComponent();
            inputTextBox.Enabled = false;
            music.URL = "VOLUME_VOLUME_mine.mp3";
            music.controls.stop();
        }

        int intNumber;
        bool blnStartFlag = false;
        int intNumberOfTries;
        bool blnSuccess;
        int intCount = 0;
        bool isActive;
        int timeMs, timeSec, timeMin;
        int intVolume = 100, intMusic = 1;
        int intLossCount = 0;
        int intWinCount = 0;

        private const int CloseButton = 0x200;
        protected override CreateParams CreateParams
        {
            //To disable the close button in the windows form
            get
            {
                CreateParams myCp = base.CreateParams;
                myCp.ClassStyle = myCp.ClassStyle | CloseButton;
                return myCp;
            }
        }

        private int GetNumber() {
            double dbValue;
            Random ranObj = new Random();
            dbValue = ranObj.NextDouble();
            return ((int)(100 * dbValue));
        }

        private bool CheckValidInput(int intInput) 
        {
            if (intInput >= 0 && intInput <= 100) {
                return true;
            }
            else
            {
                return false;
            }
        }

        private int CompareWithNumber(int intInput)
        {
            if (intInput == intNumber)
            {
                return 0;
            }
            else if (intInput < intNumber)
            {
                return -1;
            }
            else
            {
                return 1;
            }
        }

        private void Stopwatch()
        {
            //format of time display 
            msLabel.Text = String.Format("{0:00}", timeMs);
            secLabel.Text = String.Format("{0:00}", timeSec);
            minLabel.Text = String.Format("{0:00}", timeMin);
        }

        private void CountGames()
        {
            //count the number of gameplayed
            intCount++;
            tryLabel.Text = intCount.ToString();
        }

        private void RecordLogoutTime()
        {
            //Add logout time to user
            StreamWriter swTime = new StreamWriter(LoginForm.strName + ".txt", true);
            DateTime dtNow = DateTime.Now;
            swTime.WriteLine("Logout time: " + dtNow.ToString());
            swTime.Close();
        }

        private void RecordNumOfGames()
        {
            //Records down games played being 0 or more: if intGamePlayed = 0, state different message
            if (intCount > 0)
            {
                //Games played during this session
                StreamWriter swGames = new StreamWriter(LoginForm.strName + ".txt", true);
                swGames.WriteLine("Played " + intCount.ToString() + " games during this time."
                    + "\nWith " + intWinCount.ToString() + " win(s) and " + intLossCount.ToString() + " loss(es)." +
                    "\n========================================");
                swGames.Close();
            }
            else
            {
                //Games played during this session
                StreamWriter swGames = new StreamWriter(LoginForm.strName + ".txt", true);
                swGames.WriteLine("Did not play despite logining in." +
                    "\n========================================");
                swGames.Close();
            }
        }

        private void startButton_Click(object sender, EventArgs e)
        {
            isActive = true;
            blnStartFlag = true;

            intNumber = GetNumber();
            messageLabel.Text = "The game has started!";
            Thread.Sleep(100);
            inputTextBox.Text = "";
            numTriesLabel.Text = "8";

            inputTextBox.Enabled = true;
            intNumberOfTries = 8;
            startButton.Enabled = false;

            //enable mute and unmute buttons
            muteButton.Enabled = true;
            unmuteButton.Enabled = true;

            //reset values of timeSec, timeMs, timeMin, and reset label values
            timeSec = 0;
            timeMs = 0;
            timeMin = 0;
            minLabel.Text = "00";
            secLabel.Text = "00";
            msLabel.Text = "00";
            
            //read out the text in messageLabel
            string strText = messageLabel.Text;
            speaker.Rate = 2;
            speaker.Volume = intVolume;
            speaker.Speak(strText);

            //play background music
            music.settings.setMode("loop", true);
            music.controls.play();
            music.settings.volume = intMusic;
        }

        private void submitButton_Click(object sender, EventArgs e)
        {
            int intTemp = 0;
            if (blnStartFlag == false)
            {
                MessageBox.Show("Please click the start button to start!!", "Error", 
                    MessageBoxButtons.OK, MessageBoxIcon.Error);

                return;
            }
            else
            {
                try//check if input is a number or not
                {
                    intTemp = int.Parse(inputTextBox.Text);
                }
                catch
                {
                    MessageBox.Show("Please enter a number!", "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);

                    return;
                }

                blnSuccess = CheckValidInput(intTemp);
                if(blnSuccess == false)//check for number and output corresponding hints
                {
                    MessageBox.Show("Invalid input!!", "Error", 
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else if (blnSuccess == true) {
                    intNumberOfTries--;
                    numTriesLabel.Text = intNumberOfTries.ToString();
                    switch (CompareWithNumber(intTemp))
                    {
                        case 0: messageLabel.Text = "You guessed the number!!"; break;
                        case 1: messageLabel.Text = "The number is lower"; break;
                        case -1: messageLabel.Text = "The number is higher"; break;
                    }
                    if (intNumberOfTries == 0)
                    {
                        messageLabel.Text = "The game has ended. \nYou have lost.";

                        //Count number of losses
                        intLossCount++;
                        lossLabel.Text = intLossCount.ToString();

                        CountGames();

                        inputTextBox.Enabled = false;
                        blnStartFlag = false;
                        startButton.Enabled = true;
                        startButton.Text = "Restart";
                        isActive = false;
                    }
                    else if (intTemp == intNumber)
                    {
                        messageLabel.Text = "Congratulations, you guessed correctly";

                        //Count numnber of wins
                        intWinCount++;
                        winLabel.Text = intWinCount.ToString();

                        CountGames();

                        //Enable buttons and text boxes
                        inputTextBox.Enabled = false;
                        blnStartFlag = false;
                        startButton.Enabled = true;
                        startButton.Text = "Restart";
                        isActive = false;
                    }

                    //Clear then focus onto the inputTextBox
                    inputTextBox.Text = "";
                    inputTextBox.Focus();

                    //read out the text in messageLabel
                    string strText = messageLabel.Text;
                    speaker.Volume = 100;
                    speaker.Speak(strText);
                }
            }
        }

        private void muteButton_Click(object sender, EventArgs e)
        {
            //no music
            music.settings.volume = 0;
            muteButton.Hide();
            unmuteButton.Show();
            speaker.Rate = 10;
            intVolume = 0;
            intMusic = 0;

        }

        private void unmuteButton_Click(object sender, EventArgs e)
        {
            //have music
            music.settings.volume = 1;
            unmuteButton.Hide();
            muteButton.Show();
            speaker.Rate = 2;
            intVolume = 100;
            intMusic = 1;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (isActive == true)
            {
                timeMs++;

                if (timeMs >= 100)
                {
                    timeSec++;
                    timeMs = 0;

                    if (timeSec >= 60)
                    {
                        timeMin++;
                        timeSec = 0;
                    }
                }
            }
            Stopwatch();
        }

        private void exitButton_Click(object sender, EventArgs e) 
        {
            //Ask player if they want to go back to login page or exit app
            DialogResult result = MessageBox.Show("Go back to login page?", 
                "Exit Applicaiton", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                RecordLogoutTime();
                RecordNumOfGames();

                //Reset everything
                inputTextBox.Enabled = false;
                startButton.Enabled = true;
                inputTextBox.Text = "";
                numTriesLabel.Text = "0";
                startButton.Text = "Start";
                messageLabel.Text = "";
                tryLabel.Text = "0";
                intCount = 0;

                //Reset win and loss counter and labels
                intWinCount = 0;
                intLossCount = 0;
                winLabel.Text = "0";
                lossLabel.Text = "0";

                //reset values of timeSec, timeMs, and timeMin
                isActive = false;
                timeSec = 0;
                timeMs = 0;
                timeMin = 0;

                //allow another user to login
                objGuessing.Hide();
                LoginForm.objLogin.Show();
                music.controls.stop();

                return;
            }
            else if (result == DialogResult.No )
            {
                RecordLogoutTime();
                RecordNumOfGames();

                Application.Exit();
                music.controls.stop();
            }
            else if (result == DialogResult.Cancel)
            {
                return;
            }
        }
    }
}