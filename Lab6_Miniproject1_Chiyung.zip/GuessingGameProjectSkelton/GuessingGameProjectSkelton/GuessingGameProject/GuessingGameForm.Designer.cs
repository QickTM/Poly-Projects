﻿namespace GuessingGameProject
{
    partial class GuessingGameForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GuessingGameForm));
            this.submitButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.startButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.messageLabel = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.numTriesLabel = new System.Windows.Forms.Label();
            this.inputTextBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tryLabel = new System.Windows.Forms.Label();
            this.axWindowsMediaPlayer2 = new AxWMPLib.AxWindowsMediaPlayer();
            this.minLabel = new System.Windows.Forms.Label();
            this.msLabel = new System.Windows.Forms.Label();
            this.secLabel = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.muteButton = new System.Windows.Forms.Button();
            this.unmuteButton = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.scoreGroupBox = new System.Windows.Forms.GroupBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.lossLabel = new System.Windows.Forms.Label();
            this.winLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.axWindowsMediaPlayer2)).BeginInit();
            this.scoreGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // submitButton
            // 
            this.submitButton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.submitButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.submitButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.submitButton.Location = new System.Drawing.Point(605, 373);
            this.submitButton.Name = "submitButton";
            this.submitButton.Size = new System.Drawing.Size(127, 48);
            this.submitButton.TabIndex = 0;
            this.submitButton.Text = "Submit";
            this.submitButton.UseVisualStyleBackColor = false;
            this.submitButton.Click += new System.EventHandler(this.submitButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.exitButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.exitButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.exitButton.Location = new System.Drawing.Point(883, 477);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(152, 72);
            this.exitButton.TabIndex = 1;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = false;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // startButton
            // 
            this.startButton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.startButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.startButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.startButton.Location = new System.Drawing.Point(861, 137);
            this.startButton.Name = "startButton";
            this.startButton.Size = new System.Drawing.Size(152, 72);
            this.startButton.TabIndex = 2;
            this.startButton.Text = "Start";
            this.startButton.UseVisualStyleBackColor = false;
            this.startButton.Click += new System.EventHandler(this.startButton_Click);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Algerian", 25F);
            this.label1.Location = new System.Drawing.Point(246, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(689, 46);
            this.label1.TabIndex = 3;
            this.label1.Text = "Number guessing game (0 -100)";
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.label2.Location = new System.Drawing.Point(481, 70);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(230, 29);
            this.label2.TabIndex = 4;
            this.label2.Text = "(Max. 8 tries/game)";
            // 
            // messageLabel
            // 
            this.messageLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.messageLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.messageLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.messageLabel.Location = new System.Drawing.Point(156, 454);
            this.messageLabel.Name = "messageLabel";
            this.messageLabel.Size = new System.Drawing.Size(315, 116);
            this.messageLabel.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.label3.Location = new System.Drawing.Point(878, 328);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(183, 29);
            this.label3.TabIndex = 6;
            this.label3.Text = "No. of tries left:";
            // 
            // numTriesLabel
            // 
            this.numTriesLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.numTriesLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.numTriesLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.numTriesLabel.Location = new System.Drawing.Point(883, 369);
            this.numTriesLabel.Name = "numTriesLabel";
            this.numTriesLabel.Size = new System.Drawing.Size(130, 33);
            this.numTriesLabel.TabIndex = 7;
            // 
            // inputTextBox
            // 
            this.inputTextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.inputTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.inputTextBox.Location = new System.Drawing.Point(605, 325);
            this.inputTextBox.Name = "inputTextBox";
            this.inputTextBox.Size = new System.Drawing.Size(220, 36);
            this.inputTextBox.TabIndex = 8;
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.label4.Location = new System.Drawing.Point(600, 283);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(177, 29);
            this.label4.TabIndex = 9;
            this.label4.Text = "Enter Number:";
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.label5.Location = new System.Drawing.Point(68, 273);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(187, 29);
            this.label5.TabIndex = 10;
            this.label5.Text = "Games Played:";
            // 
            // tryLabel
            // 
            this.tryLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tryLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.tryLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tryLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F);
            this.tryLabel.Location = new System.Drawing.Point(73, 313);
            this.tryLabel.Name = "tryLabel";
            this.tryLabel.Size = new System.Drawing.Size(176, 98);
            this.tryLabel.TabIndex = 11;
            this.tryLabel.Text = "0";
            this.tryLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // axWindowsMediaPlayer2
            // 
            this.axWindowsMediaPlayer2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.axWindowsMediaPlayer2.Enabled = true;
            this.axWindowsMediaPlayer2.Location = new System.Drawing.Point(20, 12);
            this.axWindowsMediaPlayer2.Name = "axWindowsMediaPlayer2";
            this.axWindowsMediaPlayer2.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axWindowsMediaPlayer2.OcxState")));
            this.axWindowsMediaPlayer2.Size = new System.Drawing.Size(25, 22);
            this.axWindowsMediaPlayer2.TabIndex = 13;
            this.axWindowsMediaPlayer2.Visible = false;
            // 
            // minLabel
            // 
            this.minLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.minLabel.AutoSize = true;
            this.minLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.minLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.minLabel.Location = new System.Drawing.Point(572, 170);
            this.minLabel.Name = "minLabel";
            this.minLabel.Size = new System.Drawing.Size(55, 40);
            this.minLabel.TabIndex = 14;
            this.minLabel.Text = "00";
            this.minLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // msLabel
            // 
            this.msLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.msLabel.AutoSize = true;
            this.msLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.msLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.msLabel.Location = new System.Drawing.Point(758, 181);
            this.msLabel.Name = "msLabel";
            this.msLabel.Size = new System.Drawing.Size(32, 26);
            this.msLabel.TabIndex = 16;
            this.msLabel.Text = "00";
            this.msLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // secLabel
            // 
            this.secLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.secLabel.AutoSize = true;
            this.secLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.secLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.secLabel.Location = new System.Drawing.Point(665, 170);
            this.secLabel.Name = "secLabel";
            this.secLabel.Size = new System.Drawing.Size(55, 40);
            this.secLabel.TabIndex = 17;
            this.secLabel.Text = "00";
            this.secLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.label7.Location = new System.Drawing.Point(633, 170);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(26, 39);
            this.label7.TabIndex = 18;
            this.label7.Text = ":";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.label10.Location = new System.Drawing.Point(726, 169);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(26, 39);
            this.label10.TabIndex = 19;
            this.label10.Text = ".";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 10;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.label6.Location = new System.Drawing.Point(252, 170);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(298, 39);
            this.label6.TabIndex = 20;
            this.label6.Text = "Time played (min):";
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label8.Location = new System.Drawing.Point(224, 137);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(603, 100);
            this.label8.TabIndex = 21;
            // 
            // muteButton
            // 
            this.muteButton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.muteButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.muteButton.Location = new System.Drawing.Point(605, 481);
            this.muteButton.Name = "muteButton";
            this.muteButton.Size = new System.Drawing.Size(218, 70);
            this.muteButton.TabIndex = 22;
            this.muteButton.Text = "Mute sound";
            this.muteButton.UseVisualStyleBackColor = true;
            this.muteButton.Click += new System.EventHandler(this.muteButton_Click);
            // 
            // unmuteButton
            // 
            this.unmuteButton.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.unmuteButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.unmuteButton.Location = new System.Drawing.Point(605, 481);
            this.unmuteButton.Name = "unmuteButton";
            this.unmuteButton.Size = new System.Drawing.Size(218, 70);
            this.unmuteButton.TabIndex = 23;
            this.unmuteButton.Text = "Unmute sound";
            this.unmuteButton.UseVisualStyleBackColor = true;
            this.unmuteButton.Visible = false;
            this.unmuteButton.Click += new System.EventHandler(this.unmuteButton_Click);
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label9.Location = new System.Drawing.Point(601, 554);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(238, 20);
            this.label9.TabIndex = 24;
            this.label9.Text = "*Use headphone to hear sound";
            // 
            // scoreGroupBox
            // 
            this.scoreGroupBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.scoreGroupBox.Controls.Add(this.label11);
            this.scoreGroupBox.Controls.Add(this.label12);
            this.scoreGroupBox.Controls.Add(this.lossLabel);
            this.scoreGroupBox.Controls.Add(this.winLabel);
            this.scoreGroupBox.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.scoreGroupBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.scoreGroupBox.Location = new System.Drawing.Point(281, 258);
            this.scoreGroupBox.Name = "scoreGroupBox";
            this.scoreGroupBox.Size = new System.Drawing.Size(287, 176);
            this.scoreGroupBox.TabIndex = 25;
            this.scoreGroupBox.TabStop = false;
            this.scoreGroupBox.Text = "Score";
            // 
            // label11
            // 
            this.label11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.label11.Location = new System.Drawing.Point(151, 31);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(101, 29);
            this.label11.TabIndex = 23;
            this.label11.Text = "Losses:";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label12
            // 
            this.label12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.label12.Location = new System.Drawing.Point(18, 31);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(77, 29);
            this.label12.TabIndex = 22;
            this.label12.Text = "Wins:";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lossLabel
            // 
            this.lossLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lossLabel.BackColor = System.Drawing.Color.Red;
            this.lossLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lossLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lossLabel.ForeColor = System.Drawing.Color.Black;
            this.lossLabel.Location = new System.Drawing.Point(156, 70);
            this.lossLabel.Name = "lossLabel";
            this.lossLabel.Size = new System.Drawing.Size(105, 74);
            this.lossLabel.TabIndex = 21;
            this.lossLabel.Text = "0";
            this.lossLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // winLabel
            // 
            this.winLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.winLabel.BackColor = System.Drawing.Color.Lime;
            this.winLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.winLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.winLabel.ForeColor = System.Drawing.Color.Black;
            this.winLabel.Location = new System.Drawing.Point(23, 70);
            this.winLabel.Name = "winLabel";
            this.winLabel.Size = new System.Drawing.Size(105, 74);
            this.winLabel.TabIndex = 20;
            this.winLabel.Text = "0";
            this.winLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // GuessingGameForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1159, 602);
            this.Controls.Add(this.scoreGroupBox);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.muteButton);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.minLabel);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.msLabel);
            this.Controls.Add(this.axWindowsMediaPlayer2);
            this.Controls.Add(this.tryLabel);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.secLabel);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.inputTextBox);
            this.Controls.Add(this.numTriesLabel);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.messageLabel);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.startButton);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.submitButton);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.unmuteButton);
            this.Name = "GuessingGameForm";
            this.Text = "Guessing Game";
            ((System.ComponentModel.ISupportInitialize)(this.axWindowsMediaPlayer2)).EndInit();
            this.scoreGroupBox.ResumeLayout(false);
            this.scoreGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button submitButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button startButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label messageLabel;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label numTriesLabel;
        private System.Windows.Forms.TextBox inputTextBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label tryLabel;
        private AxWMPLib.AxWindowsMediaPlayer axWindowsMediaPlayer2;
        private System.Windows.Forms.Label minLabel;
        private System.Windows.Forms.Label msLabel;
        private System.Windows.Forms.Label secLabel;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button muteButton;
        private System.Windows.Forms.Button unmuteButton;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.GroupBox scoreGroupBox;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lossLabel;
        private System.Windows.Forms.Label winLabel;
    }
}