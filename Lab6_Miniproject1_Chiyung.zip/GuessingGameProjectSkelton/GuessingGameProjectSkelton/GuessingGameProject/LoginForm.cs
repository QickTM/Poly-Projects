﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Threading;

namespace GuessingGameProject
{
    public partial class LoginForm : Form
    {
        public static string strName;
        public static LoginForm objLogin = new LoginForm();

        public LoginForm()
        {
            InitializeComponent();
        }

        private void LoginButton_Click(object sender, EventArgs e)
        {
            try//check for correct user
            {
                string strpassword;

                if (nameTextBox.Text == "")
                {
                    msgLabel.Text = "*Login unsuccessful, please enter User ID!";
                    nameTextBox.Focus();
                }
                else if (passwordTextBox.Text == "")
                {
                    msgLabel.Text = "*Login unsuccessful, please enter Password!";
                    passwordTextBox.Focus();
                }
                else
                {
                    //Search for .txt file with the same User ID entered
                    StreamReader newUserReader = new StreamReader(nameTextBox.Text + ".txt");
                    newUserReader.ReadLine();
                    strName = newUserReader.ReadLine();
                    newUserReader.ReadLine();
                    strpassword = newUserReader.ReadLine();
                    newUserReader.Close();

                    if (strpassword == passwordTextBox.Text)
                    {
                        //clear labels
                        msgLabel.Text = "";
                        nameTextBox.Text = "";
                        passwordTextBox.Text = "";
                        Thread.Sleep(300);

                        //Add login time to .txt file
                        StreamWriter swTime = new StreamWriter(LoginForm.strName + ".txt", true);
                        DateTime dtNow = DateTime.Now;
                        swTime.WriteLine("Login time: " + dtNow.ToString());
                        swTime.Close();

                        //Hide LoginForm and show RegistraionForm
                        this.Hide();
                        GuessingGameForm.objGuessing.Show();
                    }
                    else
                    {
                        msgLabel.Text = "*Login fail, wrong \"Password\"";
                        nameTextBox.Focus();
                    }
                }
            }
            catch
            {
                msgLabel.Text = "*User ID not found";
            }
        }

        private void QuitButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void RegistrationButton_Click(object sender, EventArgs e)
        {
            //clear labels
            msgLabel.Text = "";
            nameTextBox.Text = "";
            passwordTextBox.Text = "";

            //Hide LoginForm and show RegistrationForm
            this.Hide();
            RegistrationForm.objRegForm.Show();
        }
    }
}
