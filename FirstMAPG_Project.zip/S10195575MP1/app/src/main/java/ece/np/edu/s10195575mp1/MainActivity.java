package ece.np.edu.s10195575mp1;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    Button btStart;
    RadioGroup rgOptions;
    RadioButton rbEasy, rbMedium, rbHard;
    private View.OnClickListener startListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent i = new Intent(MainActivity.this, LoginActivity.class);
            int id = rgOptions.getCheckedRadioButtonId();
            RadioButton rb = findViewById(id);

            //Set number of tries for LoginActivity
            if (rb == rbEasy) {
                i.putExtra("num_guess", "10");
            }
            else if (rb == rbMedium) {
                i.putExtra("num_guess", "5");
            }
            else if (rb == rbHard) {
                i.putExtra("num_guess", "3");
            }
            startActivity(i);
        }
    };

    private RadioGroup.OnCheckedChangeListener rgListener = new RadioGroup.OnCheckedChangeListener() {
        @Override
        public void onCheckedChanged(RadioGroup group, int checkedId) {
            RadioButton rbChoice = findViewById(checkedId);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        btStart = this.findViewById(R.id.btStart);
        btStart.setOnClickListener(startListener);
        rgOptions = this.findViewById(R.id.rgOptions);
        rbHard = this.findViewById(R.id.rbHard);
        rbEasy = this.findViewById(R.id.rbEasy);
        rbMedium = this.findViewById(R.id.rbMedium);

        rgOptions.setOnCheckedChangeListener(rgListener);


    }
}