package ece.np.edu.s10195575mp1;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    int myNumber = 5;
    int numTries;
    EditText etNumber;
    Button btSubmit, btExit, btTry;
    ImageView imageView;
    MediaPlayer correct, wrong;
    TextView tvNumTries;

    private View.OnClickListener submitListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            String guess = etNumber.getText().toString();
            if (TextUtils.isEmpty(guess)) {
                Toast.makeText(LoginActivity.this, "Please enter a number!", Toast.LENGTH_SHORT).show();
                etNumber.findFocus();
                return;
            }
            else {
                int numGuess = Integer.parseInt(guess);

                //Check if number is between 0 and 9
                if (numGuess <= 9 && numGuess >= 0) {
                    if (numGuess == myNumber) {
                        //If guessed correctly do following
                        imageView.setImageResource(R.drawable.face_correct);
                        Toast.makeText(LoginActivity.this, "Bingo! Correct Number!", Toast.LENGTH_SHORT).show();
                        MediaPlayer correct = MediaPlayer.create(LoginActivity.this, R.raw.correct_sound);
                        correct.start();
                        numTries--;
                        tvNumTries.setText(Integer.toString(numTries));
                        btTry.setEnabled(true);
                        btTry.setText("Play Again");
                        etNumber.setEnabled(false);
                        return;
                    }
                    else if (numGuess != myNumber) ;
                    {
                        //if used up number of guesses, do not allow input
                        imageView.setImageResource(R.drawable.face_wrong);
                        Toast.makeText(LoginActivity.this, "Wrong Number! Try Again", Toast.LENGTH_SHORT).show();
                        MediaPlayer wrong = MediaPlayer.create(LoginActivity.this, R.raw.wrong_sound);
                        etNumber.setText("");
                        etNumber.findFocus();
                        numTries--;
                        wrong.start();
                        tvNumTries.setText(Integer.toString(numTries));
                    }

                    if (numTries == 0) {
                        //Disable EditText
                        etNumber.setEnabled(false);
                        btTry.setEnabled(true);
                    }
                } 
                else {
                    //If number not between 0 and 9 clear and focus on EditText
                    etNumber.setText("");
                    etNumber.findFocus();
                    Toast.makeText(LoginActivity.this, "Not valid number!", Toast.LENGTH_SHORT).show();
                }
            }
        }
    };

    private View.OnClickListener exitListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent i = new Intent(LoginActivity.this, MainActivity.class);
            startActivity(i);
        }
    };

    private View.OnClickListener tryListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            finish();
            startActivity(getIntent());
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etNumber = this.findViewById(R.id.etNumber);
        btSubmit = this.findViewById(R.id.btSubmit);
        btExit = this.findViewById(R.id.btExit);
        btTry = this.findViewById(R.id.btTry);
        imageView = this.findViewById(R.id.imageView);
        tvNumTries = this.findViewById(R.id.tvNumTries);

        Intent i = this.getIntent();
        if  (i != null) {
            String str = i.getStringExtra("num_guess");
            if (str != null) {
                numTries = Integer.parseInt(str);
                tvNumTries.setText(str);
            }
        }

        btExit.setOnClickListener(exitListener);
        btSubmit.setOnClickListener(submitListener);
        btTry.setOnClickListener(tryListener);

        btTry.setEnabled(false);
    }
}

